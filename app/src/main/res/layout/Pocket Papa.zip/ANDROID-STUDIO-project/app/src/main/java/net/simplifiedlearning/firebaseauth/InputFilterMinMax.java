package net.simplifiedlearning.firebaseauth;

interface InputFilterMinMax {
}
